import { Employee, AgendaItem } from '../types';

export const DISPOSITION_HEAD: Employee = {
  id: 'emp-head',
  name: 'Yuniar Vidianto, S.T., M.T.',
  role: 'Kepala Sub Bagian Penyusunan Program dan Anggaran (Pendisposisi)',
  department: 'Subbag Penyusunan Program dan Anggaran',
  nip: '197906152005011008',
  avatarBg: 'bg-blue-700',
};

export const INITIAL_EMPLOYEES: Employee[] = [
  DISPOSITION_HEAD,
  {
    id: 'emp-dimas',
    name: 'Dimas Agung Dermawan, S.Si, M.Si',
    role: 'Statistisi Ahli Muda',
    department: 'Subbag Penyusunan Program dan Anggaran',
    nip: '199107212014031001',
    avatarBg: 'bg-violet-600',
  },
  {
    id: 'emp-agnis',
    name: 'Agnis Febiaswari, S.T.',
    role: 'Perencana Ahli Pertama',
    department: 'Subbag Penyusunan Program dan Anggaran',
    nip: '199008042014032001',
    avatarBg: 'bg-amber-600',
  },
  {
    id: 'emp-atika',
    name: "Atika Qurotu A'yun, S.Stat",
    role: 'Statistisi Ahli Pertama',
    department: 'Subbag Penyusunan Program dan Anggaran',
    nip: '199602112019032021',
    avatarBg: 'bg-emerald-600',
  },
  {
    id: 'emp-tyas',
    name: 'Tyas Basuki Priambudi, S.T.',
    role: 'Pranata Komputer Ahli Pertama',
    department: 'Subbag Penyusunan Program dan Anggaran',
    nip: '199704012020121008',
    avatarBg: 'bg-teal-600',
  },
  {
    id: 'emp-saktio',
    name: 'Saktio Bagaskoro, S.I.P.',
    role: 'Perencana Ahli Pertama',
    department: 'Subbag Penyusunan Program dan Anggaran',
    nip: '200002222025041010',
    avatarBg: 'bg-blue-600',
  },
  {
    id: 'emp-sekar',
    name: 'RR. Sekar Kalaksita, S.Si',
    role: 'Statistisi Ahli Pertama',
    department: 'Subbag Penyusunan Program dan Anggaran',
    nip: '199408132023212032',
    avatarBg: 'bg-purple-600',
  },
  {
    id: 'emp-synta',
    name: 'Synta Triasheatleyanti Ananta, S.Sos, M.M.',
    role: 'Penelaah Teknis Kebijakan',
    department: 'Subbag Penyusunan Program dan Anggaran',
    nip: '198308062010012029',
    avatarBg: 'bg-indigo-600',
  },
  {
    id: 'emp-junied',
    name: 'Junied Agus Purnomo, S.H.',
    role: 'Penelaah Teknis Kebijakan',
    department: 'Subbag Penyusunan Program dan Anggaran',
    nip: '197408292009011002',
    avatarBg: 'bg-cyan-600',
  },
  {
    id: 'emp-anang',
    name: 'M. Anang Fitrianto, S.T.',
    role: 'Pengolah Data dan Informasi',
    department: 'Subbag Penyusunan Program dan Anggaran',
    nip: '199203032015031000',
    avatarBg: 'bg-rose-600',
  },
  {
    id: 'emp-raihan',
    name: 'Raihan Adib Habibi, A.Md.Ak',
    role: 'Pengolah Data dan Informasi',
    department: 'Subbag Penyusunan Program dan Anggaran',
    nip: '200003262022021001',
    avatarBg: 'bg-sky-600',
  },
  {
    id: 'emp-rienna',
    name: 'Rienna Pratiwi Artyanti, S.E.',
    role: 'Penata Layanan Operasional',
    department: 'Subbag Penyusunan Program dan Anggaran',
    nip: '198709102025212019',
    avatarBg: 'bg-rose-700',
  },
  {
    id: 'emp-donny',
    name: 'Donny Manu, S.T.',
    role: 'Penata Layanan Operasional',
    department: 'Subbag Penyusunan Program dan Anggaran',
    nip: '198210122025211139',
    avatarBg: 'bg-emerald-700',
  },
  {
    id: 'emp-berhas',
    name: 'Berhas Ricardo Panjaitan, SAB',
    role: 'Penata Layanan Operasional',
    department: 'Subbag Penyusunan Program dan Anggaran',
    nip: '199004022025211144',
    avatarBg: 'bg-amber-700',
  },
];

export const INITIAL_AGENDAS: AgendaItem[] = [
  // Planner A: Received (Surat Masuk Diterima, belum didisposisi)
  {
    id: 'agenda-rec-01',
    letterNumber: '005/3842/BAPEDA-PROV/IX/2026',
    sender: 'Badan Perencanaan Pembangunan Daerah (BAPPEDA) Provinsi',
    letterDate: '2026-09-22',
    subject: 'Undangan Rapat Koordinasi Penyelarasan Program Kerja dan Sinkronisasi Alokasi Anggaran Triwulan IV TA 2026',
    urgency: 'Segera',
    attachmentName: 'Surat_Undangan_Bappeda_Rakor_Anggaran_2026.pdf',
    eventDate: '2026-09-24',
    startTime: '09:00',
    endTime: '12:30',
    location: 'Ruang Rapat Pimpinan Bappeda Lt. 3',
    stage: 'Received',
    createdAt: '2026-09-22T08:30:00Z',
  },
  {
    id: 'agenda-rec-02',
    letterNumber: '900/1422/BAPENDA-ANGG/2026',
    sender: 'Badan Pendapatan dan Pengelolaan Keuangan Daerah',
    letterDate: '2026-09-21',
    subject: 'Sosialisasi Tata Kelola e-Budgeting & Integrasi Pergeseran Anggaran DIPA Perubahan',
    urgency: 'Biasa',
    attachmentName: 'SE_Sosialisasi_eBudgeting_2026.pdf',
    eventDate: '2026-09-25',
    startTime: '13:00',
    endTime: '15:30',
    location: 'Aula Sasana Praja Lantai 2',
    stage: 'Received',
    createdAt: '2026-09-22T09:15:00Z',
  },

  // Planner B: In_Progress (Disposisi & Proses - ada tagging staf & catatan Kasubbag Sungram)
  {
    id: 'agenda-inp-01',
    letterNumber: 'S-1140/PB.2/KEMENKEU/2026',
    sender: 'Kementerian Keuangan RI - Ditjen Perbendaharaan',
    letterDate: '2026-09-18',
    subject: 'Petunjuk Teknis Tata Kelola Alokasi Rencana Kerja Anggaran dan Percepatan Realisasi Belanja DIPA 2026',
    urgency: 'Sangat Segera',
    attachmentName: 'Petunjuk_Teknis_DIPA_Kemenkeu.pdf',
    eventDate: '2026-09-23',
    startTime: '08:30',
    endTime: '11:30',
    location: 'Ruang Rapat Subbag Sungram & Virtual Zoom',
    stage: 'In_Progress',
    createdAt: '2026-09-18T10:00:00Z',
    disposition: {
      assignedEmployeeIds: ['emp-synta', 'emp-junied', 'emp-raihan'],
      disposerName: 'Yuniar Vidianto, S.T., M.T.',
      disposerRole: 'Kasubbag Sungram',
      disposerNote: 'Pelajari petunjuk teknis revisi pagu, siapkan matriks serapan anggaran per bidang, dan koordinasikan dengan bendahara pengeluaran.',
      disposedAt: '2026-09-19T08:45:00Z',
      priority: 'Mendesak',
    },
  },
  {
    id: 'agenda-inp-02',
    letterNumber: '027/SP/SARPRAS-DISHUB/IX/2026',
    sender: 'Bagian Rumah Tangga & Perlengkapan Kantor',
    letterDate: '2026-09-17',
    subject: 'Rapat Pembahasan Usulan Rencana Kebutuhan Sarana Prasarana dan TI Subbag Sungram 2027',
    urgency: 'Biasa',
    attachmentName: 'RKA_Sarpras_TI_2027.pdf',
    eventDate: '2026-09-23',
    startTime: '14:00',
    endTime: '16:00',
    location: 'Ruang Rapat Subbag Lantai 2',
    stage: 'In_Progress',
    createdAt: '2026-09-17T11:20:00Z',
    disposition: {
      assignedEmployeeIds: ['emp-tyas', 'emp-anang'],
      disposerName: 'Yuniar Vidianto, S.T., M.T.',
      disposerRole: 'Kasubbag Sungram',
      disposerNote: 'Cek daftar inventaris sarpras kerja yang butuh peremajaan, susun rincian kebutuhan riil sesuai standar biaya umum.',
      disposedAt: '2026-09-18T09:10:00Z',
      priority: 'Biasa',
    },
  },

  // Planner C: Completed (Selesai - staf telah mengisi laporan pelaksanaan disposisi)
  {
    id: 'agenda-cmp-01',
    letterNumber: '700/081/INSP-WAS/2026',
    sender: 'Inspektorat Daerah Kota',
    letterDate: '2026-09-12',
    subject: 'Entry Meeting Pengawasan dan Evaluasi Akuntabilitas Kinerja Instansi Pemerintah (AKIP/SAKIP) 2026',
    urgency: 'Sangat Segera',
    attachmentName: 'Surat_Tugas_Wasrik_Inspektorat.pdf',
    eventDate: '2026-09-16',
    startTime: '09:00',
    endTime: '12:00',
    location: 'Ruang Rapat Utama Inspektorat',
    stage: 'Completed',
    createdAt: '2026-09-12T14:00:00Z',
    disposition: {
      assignedEmployeeIds: ['emp-dimas', 'emp-atika', 'emp-sekar'],
      disposerName: 'Yuniar Vidianto, S.T., M.T.',
      disposerRole: 'Kasubbag Sungram',
      disposerNote: 'Dampingi tim pemeriksa pengawas internal, siapkan berkas Renstra, IKU, dan laporan capaian target kinerja triwulan.',
      disposedAt: '2026-09-13T08:15:00Z',
      priority: 'Penting',
    },
    report: {
      reportedByEmployeeId: 'emp-dimas',
      reportedByName: 'Dimas Agung Dermawan, S.Si, M.Si',
      reportedAt: '2026-09-16T15:30:00Z',
      executionNotes: `Menindaklanjuti Surat dari Inspektorat Daerah Kota, Nomor 700/081/INSP-WAS/2026, bersama ini dilaporkan dengan hormat hasil giat Entry Meeting Pengawasan dan Evaluasi Akuntabilitas Kinerja Instansi Pemerintah (AKIP/SAKIP) 2026 dengan rincian sebagai berikut:

I. PELAKSANAAN
Hari : Rabu
Tanggal : 16 September 2026
Tempat: Ruang Rapat Utama Inspektorat

II. HADIR DALAM KEGIATAN
Dibuka oleh : Inspektur Daerah Kota
Pimpinan : Pengendali Teknis Tim Wasrik Inspektorat
Peserta :
1. Subbag Penyusunan Program dan Anggaran
2. Tim Auditor Inspektorat Daerah
3. Seluruh Pengampu Program & Kegiatan

III. SUBSTANSI
1. Landasan Hukum :
   a) PermenPAN-RB Nomor 88 Tahun 2021 tentang Evaluasi Akuntabilitas Kinerja Instansi Pemerintah
2. Tujuan Umum : Pelaksanaan Evaluasi dan Pembinaan AKIP/SAKIP Subbag Sungram
   Tujuan Khusus :
   a) Verifikasi kelengkapan dokumen Renstra, Perjanjian Kinerja (PK), dan IKU
   b) Penyelarasan matriks cascading indikator kinerja program
3. Hasil Kegiatan / Pembahasan :
   a. Seluruh data dukung SAKIP dan formulir monev telah diserahkan dan dinyatakan lengkap
   b. Nilai evaluasi sementara menunjukkan predikat Sangat Baik (A)

IV. TINDAK LANJUT
1. Melakukan perbaikan redaksional indikator output dalam waktu 3 hari kerja
2. Mengunggah perbaikan matriks SAKIP pada portal pengawasan daerah

Demikian dilaporkan untuk dapat menjadi periksa dan mohon petunjuk/arahan lebih lanjut.`,
      followUpAction: 'Melakukan upload perbaikan matriks SAKIP pada portal pengawasan daerah.',
      photos: [
        {
          id: 'ph-1',
          url: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=600&q=80',
          caption: 'Pelaksanaan Entry Meeting bersama Auditor Inspektorat',
          uploadedAt: '2026-09-16',
        },
      ],
    },
  },
];
