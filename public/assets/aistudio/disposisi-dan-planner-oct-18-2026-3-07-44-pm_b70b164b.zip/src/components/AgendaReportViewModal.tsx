import React, { useState } from 'react';
import { 
  X, 
  FileText, 
  Copy, 
  Printer, 
  Edit3, 
  CheckCircle2, 
  Calendar, 
  MapPin, 
  User, 
  Image as ImageIcon,
  ExternalLink,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { AgendaItem, AgendaReport } from '../types';

interface AgendaReportViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  agenda: AgendaItem | null;
  onEditReport?: (agenda: AgendaItem) => void;
}

export const AgendaReportViewModal: React.FC<AgendaReportViewModalProps> = ({
  isOpen,
  onClose,
  agenda,
  onEditReport,
}) => {
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState<number | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen || !agenda || !agenda.report) return null;

  const report = agenda.report;

  const handleCopy = () => {
    const text = report.fullReportText || (
      `${report.openingText}\n\n` +
      `I. PELAKSANAAN\n` +
      `Hari : ${report.pelaksanaan.hari}\n` +
      `Tanggal : ${report.pelaksanaan.tanggal}\n` +
      `Tempat: ${report.pelaksanaan.tempat}\n\n` +
      `II. HADIR DALAM RAPAT\n` +
      `Pimpinan : ${report.hadir.pimpinan}\n` +
      `Peserta :\n${report.hadir.peserta.join('\n')}\n\n` +
      `III. SUBSTANSI\n` +
      `${report.substansi.join('\n')}\n\n` +
      `${report.penutup}`
    );

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div 
        className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400 shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white leading-tight">
                  Laporan Hasil Pelaksanaan Kegiatan
                </h3>
                <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Status: Selesai
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 truncate max-w-md">
                Agenda: {agenda.title}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onEditReport && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onEditReport(agenda);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition-colors border border-slate-700"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit Laporan</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
              aria-label="Tutup"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Action Bar */}
        <div className="px-6 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0 flex-wrap gap-2">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span>Pelapor: <strong className="text-slate-800">{report.reportedByName}</strong></span>
            <span>•</span>
            <span>Dilaporkan: <strong className="text-slate-700">{report.reportedAt}</strong></span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-lg text-xs font-bold transition-colors shadow-2xs"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copied ? 'Tersalin!' : 'Salin Teks (WhatsApp/Nota)'}</span>
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-lg text-xs font-bold transition-colors shadow-2xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Laporan</span>
            </button>
          </div>
        </div>

        {/* Report Paper Content */}
        <div className="p-6 sm:p-8 overflow-y-auto flex-1 space-y-6 bg-white print:p-0">
          <div className="border-b-2 border-slate-900 pb-3 text-center">
            <h2 className="text-base font-extrabold uppercase tracking-wider text-slate-900">
              Laporan Hasil Pelaksanaan Kegiatan
            </h2>
            <p className="text-xs text-slate-600 mt-1 font-medium">
              Sub Bagian Penyusunan Program dan Anggaran • Dinas Perhubungan Provinsi Jawa Timur
            </p>
          </div>

          <p className="text-xs text-slate-800 leading-relaxed font-medium">
            {report.openingText}
          </p>

          {/* Section I */}
          <div className="text-xs space-y-1.5">
            <h4 className="font-extrabold text-slate-900 uppercase tracking-wide">I. PELAKSANAAN</h4>
            <div className="pl-4 space-y-1 text-slate-800">
              <div className="flex"><span className="w-20 text-slate-600 font-semibold">Hari</span>: {report.pelaksanaan.hari}</div>
              <div className="flex"><span className="w-20 text-slate-600 font-semibold">Tanggal</span>: {report.pelaksanaan.tanggal}</div>
              <div className="flex"><span className="w-20 text-slate-600 font-semibold">Tempat</span>: {report.pelaksanaan.tempat}</div>
            </div>
          </div>

          {/* Section II */}
          <div className="text-xs space-y-1.5">
            <h4 className="font-extrabold text-slate-900 uppercase tracking-wide">II. HADIR DALAM RAPAT</h4>
            <div className="pl-4 space-y-1.5 text-slate-800">
              <div className="flex"><span className="w-20 text-slate-600 font-semibold">Pimpinan</span>: {report.hadir.pimpinan}</div>
              <div>
                <span className="text-slate-600 font-semibold block mb-1">Peserta :</span>
                <ul className="list-decimal list-inside pl-2 space-y-1 text-slate-700">
                  {report.hadir.peserta.map((peserta, idx) => (
                    <li key={idx} className="leading-relaxed">{peserta.replace(/^\d+\.\s*/, '')}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Section III */}
          <div className="text-xs space-y-1.5">
            <h4 className="font-extrabold text-slate-900 uppercase tracking-wide">III. SUBSTANSI</h4>
            <div className="pl-4 space-y-1 text-slate-800 leading-relaxed">
              {report.substansi.map((item, idx) => {
                const isSubBullet = item.trim().startsWith('*') || item.trim().startsWith('-');
                return (
                  <div 
                    key={idx} 
                    className={isSubBullet ? "pl-5 text-slate-700 text-[11px]" : "font-medium text-slate-900 mt-1"}
                  >
                    {item}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Penutup */}
          <p className="text-xs text-slate-800 leading-relaxed font-medium pt-2">
            {report.penutup}
          </p>

          {/* Photos Gallery */}
          {report.photos && report.photos.length > 0 && (
            <div className="pt-5 border-t border-slate-200 space-y-3">
              <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-emerald-600" />
                <span>Dokumentasi Foto Kegiatan ({report.photos.length} Gambar)</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {report.photos.map((photo, i) => (
                  <div
                    key={photo.id}
                    onClick={() => setSelectedPhotoIndex(i)}
                    className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50 group cursor-pointer hover:border-blue-400 hover:shadow-md transition-all"
                  >
                    <div className="h-48 w-full overflow-hidden bg-slate-900 relative">
                      <img
                        src={photo.url}
                        alt={photo.caption || `Dokumentasi ${i + 1}`}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white text-xs font-semibold gap-1 transition-opacity">
                        <ExternalLink className="w-4 h-4" />
                        <span>Perbesar Foto</span>
                      </div>
                    </div>
                    <div className="p-2.5 bg-white">
                      <p className="text-xs font-semibold text-slate-800 line-clamp-2">
                        {photo.caption || `Foto Dokumentasi Kegiatan #${i + 1}`}
                      </p>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Unggah: {photo.uploadedAt}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Footer Signature */}
          <div className="pt-6 border-t border-slate-100 flex justify-end">
            <div className="text-right text-xs">
              <p className="text-slate-500">Dilaporkan oleh:</p>
              <p className="font-extrabold text-slate-900 mt-1">
                {report.reportedByName}
              </p>
              <p className="text-[11px] text-slate-500">
                {report.reportedByRole || 'Pegawai Terdisposisi Subbag Program & Anggaran'}
              </p>
            </div>
          </div>
        </div>

        {/* Lightbox for photo enlarge */}
        {selectedPhotoIndex !== null && report.photos[selectedPhotoIndex] && (
          <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
            <div className="relative max-w-4xl max-h-[90vh] bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 flex flex-col">
              <div className="p-3 bg-slate-900 flex items-center justify-between text-white text-xs">
                <span className="font-semibold">
                  Foto #{selectedPhotoIndex + 1} dari {report.photos.length}: {report.photos[selectedPhotoIndex].caption}
                </span>
                <button
                  onClick={() => setSelectedPhotoIndex(null)}
                  className="p-1 hover:bg-white/20 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-hidden flex items-center justify-center bg-black p-2">
                <img
                  src={report.photos[selectedPhotoIndex].url}
                  alt={report.photos[selectedPhotoIndex].caption}
                  className="max-w-full max-h-[75vh] object-contain rounded-lg"
                />
              </div>

              <div className="p-3 bg-slate-900 flex items-center justify-between text-xs text-slate-300">
                <button
                  disabled={selectedPhotoIndex === 0}
                  onClick={() => setSelectedPhotoIndex((prev) => (prev !== null && prev > 0 ? prev - 1 : prev))}
                  className="flex items-center gap-1 px-3 py-1 bg-white/10 hover:bg-white/20 rounded-lg disabled:opacity-30"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Sebelumnya</span>
                </button>
                <span>{report.photos[selectedPhotoIndex].caption}</span>
                <button
                  disabled={selectedPhotoIndex === report.photos.length - 1}
                  onClick={() => setSelectedPhotoIndex((prev) => (prev !== null && prev < report.photos.length - 1 ? prev + 1 : prev))}
                  className="flex items-center gap-1 px-3 py-1 bg-white/10 hover:bg-white/20 rounded-lg disabled:opacity-30"
                >
                  <span>Selanjutnya</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="text-xs text-emerald-700 font-semibold flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4" />
            <span>Laporan sah dan telah terintegrasi dalam sistem arsip kegiatan dinas</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-700 bg-slate-200 hover:bg-slate-300 rounded-xl transition-colors"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
